#include "n2/dynamicdistance.h"

using namespace std;
namespace n2{
    dynamicdistance::~dynamicdistance(){

    }

    void printf(const vector<float> &c){
        for(int i=0;i<c.size();i++){
            cout<<c[i]<< " ";
        }
        cout<< " " << endl;
    }

    dynamicdistance::dynamicdistance(int a,int b){
        this->textnum = a;
        this->contnum = b;
    }

    float dynamicdistance::compute(const vector<float>& a,const vector<float>& b,const vector<float> &c){
        vector<float> a1(&a[0],&a[0]+textnum);//a的text值
        vector<float> a2(&a[0]+textnum,&a[0]+textnum+contnum);//a的cont属性

        vector<float> b1(&b[0],&b[0]+textnum);//b的text值
        vector<float> b2(&b[0]+textnum,&b[0]+textnum+contnum);//b的cont属性

        vector<float> c1(&c[0],&c[0]+2);
        vector<float> c2(&c[0]+2,&c[0]+2+textnum);
        vector<float> c3(&c[0]+2+textnum,&c[0]+2+textnum+contnum);
        
        // cout<< " a1"<<endl;
        // printf(a1);
        // printf(a2);

        float Jdist = dynamicdistance::Jdistance(a1,b1,c2);
        float Mdist = dynamicdistance::Mdistance(a2,b2,c3);
        float result = Jdist*c1[0]+Mdist*c1[1];
        // cout<<" c1 "<<endl;
        // printf(c1);
        // printf(c3);

        // cout<<"jdist"<<Jdist<<endl;
        // cout<<"mdist"<<Mdist<<endl;


        vector<float>().swap(a1);
        vector<float>().swap(a2);
        vector<float>().swap(b1);
        vector<float>().swap(b2);
        vector<float>().swap(c1);
        vector<float>().swap(c2);
        vector<float>().swap(c3);
        return result;
    }

    void dynamicdistance::setsize(int a,int b){
        this->textnum = a;
        this->contnum = b;
    }
    
    float dynamicdistance::Jdistance(const vector<float>& a,const vector<float>& b,const vector<float>& c){
        float up = 0,down=0;
        for(int i=0;i<textnum;i++){
            up +=a[i]*b[i]*c[i];
            down += (a[i]*a[i]+b[i]*b[i]-a[i]*b[i])*c[i];
        }
        if(down==0){
            return 1;
        }else
        {
            float result = up/down;
            return 1-result;
        }
    }
    
    float dynamicdistance::Mdistance(const vector<float>& a,const vector<float>& b,const vector<float>& c){
        float result = 0;
        // int dim = a.size;
        for(int i=0;i<contnum;i++){
            result += abs(a[i] - b[i])*c[i];
        }
        return result;
    }

    // int main(int argc, char **argv){
    //     dynamicdistance d = 
    // }

}