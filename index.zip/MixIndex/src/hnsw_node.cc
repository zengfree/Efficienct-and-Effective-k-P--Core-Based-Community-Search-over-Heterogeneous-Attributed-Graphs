// Copyright 2017 Kakao Corp. <http://www.kakaocorp.com>
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include <vector>

#include "n2/hnsw_node.h"
#include "string.h"

namespace n2
{

    HnswNode::HnswNode(int id, const Data *data, int attributesNumber, const std::vector<int> &attr, int maxsize /*, int maxsize0*/)
        : id_(id), data_(data), attributes_number_(attributesNumber), attributes_(attr), maxsize_(maxsize)
    {
    }

    // 预先分配0层的内存
    void HnswNode::CopyDataAndLevel0LinksToOptIndex(char *mem_offset, int higher_level_offset, int maxsize) const
    {
        // 0层的起始地址
        char *mem_data = mem_offset;
        // 分配单层的内存
        CopyLinksToOptIndex(mem_data, 0);
        mem_data += (sizeof(int) + sizeof(int) * maxsize);
        std::vector<float> data = data_->GetData();
        memcpy(mem_data, data.data(), data.size() * sizeof(float));
        mem_data += data.size() * sizeof(float);
        memcpy(mem_data, attributes_.data(), attributes_.size() * sizeof(char));
        // for (size_t i = 0; i < attributes_.size(); i++)
        // {
        //     *((char *)(mem_data)) = (char)attributes_[i];
        //     std::cout << (int)attributes_[i] << std::endl;
        //     mem_data += sizeof(char);
        // }
        // std::cout << "test_0_1\n";
    }

    void HnswNode::CopyLinksToOptIndex(char *mem_offset, int level) const
    {
        // 本层存储开始的起始地址
        char *mem_data = mem_offset;
        const auto &neighbors = friends_;
        // mem_data指向的地址存储内容为邻居的数量
        int k = (int)(neighbors.size());
        memcpy(mem_data, &k, sizeof(int));
        // 本层的起始地址加上邻居的数量所需要的内存空间（sizeof(int)）即为下一步的起始地址
        mem_data += sizeof(int);
        // 从地址mem_data开始将每个邻居的id（int）一次存入
        // memcpy(mem_data, neighbors.data(), sizeof(int) * k);
        for (int i = 0; i < k; ++i)
        {
            *((int *)(mem_data)) = (int)neighbors[i]->GetId();
            mem_data += sizeof(int);
        }
    }

    float HnswNode::GetDistanceWithAttribute(HnswNode *node_a)
    {
        float result = 0;
        for (int i = 0; i < attributes_number_; i++)
        {
            if (node_a->attributes_[i] != attributes_[i])
                result++;
        }
        return result;
    }

    float HnswNode::GetDistanceWithAttribute(std::vector<char> attribute)
    {
        float result = 0;
        for (int i = 0; i < attributes_number_; i++)
        {
            if (attribute[i] != attributes_[i])
                result++;
        }
        return result;
    }

} // namespace n2
