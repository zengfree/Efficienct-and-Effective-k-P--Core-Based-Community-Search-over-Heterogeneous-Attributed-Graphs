## AUTHORS
- Dong-hee Na <denny.na@kakaocorp.com>
- Kwangseob Kim <lucas.kim@kakaocorp.com>
- HeeKyung Yoon <hee.yoon@kakaocorp.com> 
- Hyunjong Lee <peter.hyunjong@kakaocorp.com>
- Jisang Yoon <jason.yoon@kakaocorp.com>
- Seongjin Kim <nick.kim@kakaocorp.com>
- Tackhee Lee <leeth92@naver.com>
