#pragma once

#include <iostream>
#include <vector>
#include<cmath>

using namespace std;
namespace n2{
    class dynamicdistance{
        private:
        int textnum;
        int contnum;
        public:
        dynamicdistance(/* args */);
        dynamicdistance(int a,int b);
        ~dynamicdistance();
        float compute(const vector<float>& a,const vector<float>& b,const vector<float>& c);
        void setsize(int a,int b);
        float Jdistance(const vector<float>& a,const vector<float>& b,const vector<float>& c);
        float Mdistance(const vector<float>& a,const vector<float>& b,const vector<float>& c);
    };
}