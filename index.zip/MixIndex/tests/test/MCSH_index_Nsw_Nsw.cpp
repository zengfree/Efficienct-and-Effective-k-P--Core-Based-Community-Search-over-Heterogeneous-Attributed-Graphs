#include "n2/hnsw.h"
#include "n2/dynamicdistance.h"

#include <string>
#include <vector>
#include <random>
#include <iostream>
#include <algorithm>
#include <time.h>
#include <sys/time.h>
#include <stdio.h>
#include <map>
#include <cstring>
#include <fstream>
#include "MCSH_index_Nsw_Nsw.h"

  void SplitString(const string &s, vector<float> &v, const string &c)
{
    string::size_type pos1, pos2;
    pos2 = s.find(c);
    pos1 = 0;
    int i =0;

    while (string::npos != pos2)
    {
      
        pos1 = pos2 + c.size();
        pos2 = s.find(c, pos1);
        v.push_back(atof(s.substr(pos1, pos2 - pos1).c_str()));
    }
    
}

  void SplitString(const string &s, vector<int> &v, const string &c)
{
    string::size_type pos1, pos2;
    pos2 = s.find(c);
    pos1 = 0;
    int i =0;

    while (string::npos != pos2)
    {
        v.push_back(atof(s.substr(pos1, pos2 - pos1).c_str()));
        pos1 = pos2 + c.size();
        pos2 = s.find(c, pos1);
    }
    
}

char* jstringToChar(JNIEnv* env, jstring jstr) {
    char* rtn = NULL;
    jclass clsstring = env->FindClass("java/lang/String");
    jstring strencode = env->NewStringUTF("GB2312");
    jmethodID mid = env->GetMethodID(clsstring, "getBytes", "(Ljava/lang/String;)[B");
    jbyteArray barr = (jbyteArray) env->CallObjectMethod(jstr, mid, strencode);
    jsize alen = env->GetArrayLength(barr);
    jbyte* ba = env->GetByteArrayElements(barr, JNI_FALSE);
    if (alen > 0) {
        rtn = (char*) malloc(alen + 1);
        memcpy(rtn, ba, alen);
        rtn[alen] = 0;
    }
    env->ReleaseByteArrayElements(barr, ba, 0);
    return rtn;
}

  std::string jstring2str(JNIEnv* env, jstring jstr)
{   
       // jstring 转 char*
   char* chardata = jstringToChar(env, jstr);
   // char* 转 string
   std::string str = chardata;
   return str;
}

void printf(const vector<float> &c){
    for(int i=0;i<c.size();i++){
        cout<<c[i]<< " ";
    }
    cout<< " " << endl;
}

void printf(const vector<int> &c){
    for(int i=0;i<c.size();i++){
        cout<<c[i]<< " ";
    }
    cout<< " " << endl;
}

JNIEXPORT jintArray JNICALL Java_MCSH_index_Nsw_Nsw_search
(JNIEnv *evn, jobject jobject, jfloatArray qvec, jint queryK, jint queryN, jint ef, jstring indexfile, jfloatArray prevector, jint textnum, jint contnum){
    int tnum = (int) textnum;
    int cnum = (int) contnum;
    jfloat* vecdata = (jfloat *)evn->GetFloatArrayElements(prevector,0);
    jsize vecsize = evn->GetArrayLength(prevector);
    std::vector<float> prevec;
    for(int i=0; i< vecsize ;i++){
        prevec.push_back(vecdata[i]);
    }

    n2::Hnsw index(tnum,cnum,prevec);
    std::string indexModel = jstring2str(evn,indexfile);
    std::string attributeModel = indexModel;
    attributeModel.insert(attributeModel.find(".n2"),"att");
    index.LoadModel(indexModel);
    index.LoadAttributeTable(attributeModel);
    // cout << "load index" + indexModel <<endl;
    // cout << "load attribute table" + indexModel <<endl;

    int search_k = (int) queryN;
    int ef_search = (int) ef;
    vector<pair<int, float>> result;
    vector<int> m(search_k);
    jfloat* qvecdata = (jfloat *)evn->GetFloatArrayElements(qvec,0);
    jsize qvecsize = evn->GetArrayLength(qvec);
    vector<float> inquire;
    std::vector<int> v;
    v.push_back((int) queryK);
    for(int i=0; i< qvecsize ;i++){
        inquire.push_back(qvecdata[i]);
    }

    index.SearchByVector_new(inquire,v, search_k, ef_search, result);
    for(int j = 0; j <result.size(); j++){
        m[j] = result[j].first;
    }

    jintArray jarray = evn->NewIntArray(search_k);
    jint *jnum = new jint[search_k];
    for(int i=0;i<search_k;i++){
        *(jnum+i) = m[i];
    }
    evn->SetIntArrayRegion(jarray,0,search_k,jnum);
    return jarray;
}

JNIEXPORT void JNICALL Java_MCSH_index_Nsw_Nsw_build
  (JNIEnv *evn, jobject jobject, jstring datafile, jstring indexfile, jfloatArray prevector, jint textnum, jint contnum, jint M, jint ef){
    int tnum = (int) textnum;
    int cnum = (int) contnum;
    jfloat* vecdata = (jfloat *)evn->GetFloatArrayElements(prevector,0);
    jsize vecsize = evn->GetArrayLength(prevector);
    std::vector<float> prevec;
    //输出偏好向量
    for(int i=0; i< vecsize ;i++){
        prevec.push_back(vecdata[i]);
    }
    cout<< "prevec" <<endl;
    printf(prevec);
    
    n2::Hnsw index(tnum,cnum,prevec);
    //读入数据文件
    ifstream mydataread(jstring2str(evn,datafile));
    if (!mydataread.is_open()){
        cout << "未成功打开文件" << endl;
    }
    string temp;
    while (getline(mydataread,temp))
    {
        std::vector<float> tmp;
        SplitString(temp,tmp," ");
        index.AddData(tmp);
        // printf(tmp);

        getline(mydataread,temp);
        std::vector<int> tmp2;
        SplitString(temp,tmp2," ");
        index.AddAllNodeAttributes(tmp2);
        // printf(tmp2);
    //   vector<float>().swap(tmp);
    }
    mydataread.close();
    cout << "读入" << index.data_num() << "条数据" << endl;
        
    vector<pair<string, string>> configs = {{"M", to_string((int)M)}, {"MaxM0", "10"}, {"NumThread", "4"}, {"efConstruction",to_string((int)ef)}};//每个点的近邻
    index.SetConfigs(configs);
    index.Fit();

    // index.SaveModel(jstring2str(evn,indexfile));
    std::string indexModel = jstring2str(evn,indexfile);
    index.SaveModel(indexModel);
    cout << "save index" + indexModel <<endl;
    std::string attributeModel = indexModel;
    attributeModel.insert(attributeModel.find(".n2"),"att");
    index.SaveAttributeTable(attributeModel);
    cout << "save attribute table" + attributeModel <<endl;
    cout << "build succeed" <<endl;
    // index.printneighbors("/home/hadoop/neibors.txt");
    
  }